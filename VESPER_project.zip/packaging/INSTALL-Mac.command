#!/bin/bash
cd "$(dirname "$0")"
VST3="$HOME/Library/Audio/Plug-Ins/VST3"
AU="$HOME/Library/Audio/Plug-Ins/Components"
mkdir -p "$VST3" "$AU"
rm -rf "$VST3/VESPER.vst3" "$AU/VESPER.component"
cp -R VESPER.vst3 "$VST3/"
if [ -d VESPER.component ]; then cp -R VESPER.component "$AU/"; fi
xattr -dr com.apple.quarantine "$VST3/VESPER.vst3" 2>/dev/null
xattr -dr com.apple.quarantine "$AU/VESPER.component" 2>/dev/null
echo ""
echo "VESPER is installed. In FL Studio: Options > Manage plugins > Find installed plugins."
echo ""
