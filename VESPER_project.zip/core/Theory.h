// VESPER chord engine — music theory core (no JUCE, safe to unit test).
// Everything the audio thread touches uses fixed-size types (no heap).
#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace vesper
{
//==============================================================================
// Small fixed-capacity list of ints (MIDI notes or intervals).
struct Notes
{
    static constexpr int cap = 16;
    std::array<int, cap> v {};
    int n = 0;

    void add (int x)                 { if (n < cap) v[(size_t) n++] = x; }
    int size() const                 { return n; }
    bool empty() const               { return n == 0; }
    void clear()                     { n = 0; }
    int operator[] (int i) const     { return v[(size_t) i]; }
    int& operator[] (int i)          { return v[(size_t) i]; }
    void sort();
    void unique();                   // sorts and removes duplicates
    bool contains (int x) const;
    int lowest() const;
    int highest() const;
    void transpose (int semis)       { for (int i = 0; i < n; ++i) v[(size_t) i] += semis; }
    void removeAt (int i);
    double mean() const;
    bool sameAs (const Notes& o) const;   // same notes regardless of order
};

//==============================================================================
struct Rng
{
    uint32_t s = 0x9E3779B9u;
    uint32_t next()   { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    int below (int n) { return n <= 1 ? 0 : (int) (next() % (uint32_t) n); }
    float unit()      { return (float) (next() & 0xFFFFFF) / (float) 0x1000000; }
};

//==============================================================================
struct Quality
{
    std::string suffix;     // "m7b5"
    std::string name;       // "Half-diminished 7"
    std::string group;      // "Sevenths"
    std::vector<int> iv;    // semitones from the root, extensions above 12
};

const std::vector<Quality>& qualities();
int numQualities();
int findQuality (const std::string& suffix);           // -1 if unknown
const std::vector<std::string>& qualityGroups();      // display order

struct Scale
{
    std::string name;
    std::vector<int> iv;
    int poolScale;          // scale used to decide which chords "fit" (pentatonics use their parent)
};

const std::vector<Scale>& scales();
int numScales();

enum Genre { Soul = 0, Jazz, Gospel, Rock, Pop, HipHop, Trap, Drill, NeoSoul, LoFi, Funk, House, Afro, Latin,
             Reggaeton, Reggae, Country, Blues, Cinematic, numGenres };
int genreFamily (int g);             // the closest of the first four (for colour chords)
const char* genreName (int g);       // "SOUL / R&B"
const char* genreShort (int g);      // "SOUL"

//==============================================================================
struct Chord
{
    int root = 0;           // pitch class 0..11
    int quality = -1;       // index into qualities(); -1 = empty
    int bass = -1;          // pitch class of a slash bass, -1 = none

    bool valid() const { return quality >= 0 && quality < numQualities(); }
    bool operator== (const Chord& o) const { return root == o.root && quality == o.quality && bass == o.bass; }
    bool operator!= (const Chord& o) const { return ! (*this == o); }
    int id() const { return valid() ? ((root * 128 + quality) * 13 + (bass + 1)) : -1; }
};

Chord makeChord (int root, const std::string& suffix, int bass = -1);
Notes chordIntervals (const Chord&);  // the quality's intervals (root = 0)
int pcMask (const Chord&);             // 12-bit set of the chord's pitch classes (incl. slash bass)
int tonesMask (const Chord&);          // pitch classes relative to the root (bit 0 = root)

std::string noteName (int pc, bool flats);
std::string midiName (int midiNote, bool flats);      // FL Studio octave numbering (MIDI 60 = C5)
bool keyPrefersFlats (int keyRoot, int scale);
std::string chordName (const Chord&, bool flats);
std::string romanNumeral (const Chord&, int keyRoot);

int scaleMask (int keyRoot, int scale);
int poolMask (int keyRoot, int scale);
bool fitsScale (const Chord&, int keyRoot, int scale);
bool scaleIsMajorType (int scale);

enum class Role { Home, Move, Pull, Color };
Role chordRole (const Chord&, int keyRoot, int scale);
const char* roleWord (Role);

//==============================================================================
// SCALE mode: every chord in the key, one chord per key on the keyboard.
// Each octave is a chord family; white keys are the scale's degrees,
// black keys hold extra in-key chords, then a few genre "outside" colors.
constexpr int numRows = 11;
const char* rowName (int row);
inline int rowBaseNote (int row) { return row * 12; }

struct KeySlot
{
    Chord chord;
    bool outside = false;   // not in the key/scale (genre color)
    int degree = -1;        // scale degree for white keys, -1 otherwise
};

struct ScaleMap
{
    std::array<KeySlot, 128> keys {};
    std::array<std::vector<Chord>, numRows> overflow;   // in-key chords that didn't get a key
    std::vector<Chord> allInKey;                         // every in-key chord, for display/suggestions
};

ScaleMap buildScaleMap (int keyRoot, int scale, int genre);

//==============================================================================
// PADS mode: 24 curated chords per genre.
constexpr int paletteSize = 24;

struct Card
{
    Chord chord;
    int style = -1;         // -1 = follow the global voicing
    int variant = -1;       // -1 = automatic
};

using Palette = std::array<Card, paletteSize>;
Palette buildPalette (int keyRoot, int scale, int genre, uint32_t diceSeed);   // seed 0 = the classic set

//==============================================================================
struct TriadInfo
{
    int root = 0;
    int type = 0;           // 0 maj, 1 min, 2 dim, 3 aug, 4 sus2, 5 sus4
    std::array<int, 3> iv {};   // intervals from the triad root (0, x, y)
    std::string name;
};

std::vector<TriadInfo> triadsIn (const Chord&, bool flats);
Notes triadNotes (const TriadInfo&, int inversion, int octave);   // octave in FL numbering (MIDI = 12*octave + pc)

//==============================================================================
struct Suggestion
{
    Chord chord;
    std::string why;        // "goes home", "builds tension"...
};

std::vector<Suggestion> suggestNext (const Chord& current, int keyRoot, int scale,
                                     const std::vector<Chord>& available);
} // namespace vesper
