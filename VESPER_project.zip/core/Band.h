// VESPER band: generative melody, counter-melody, bass, strings, horns and drums that follow the
// chords you play. Pure C++ (no JUCE), fixed-size state, no heap on the play path.
//
// How it stays musical: each part builds a one-bar "plan" (rhythm + melodic intentions) from its
// seed. Plans repeat across a phrase in an A A' B A shape, so you get hooks and riffs instead of
// random notes, while the actual pitches are worked out against whatever chord is playing.
#pragma once

#include "Theory.h"
#include "Phrases.h"

namespace vesper
{
enum BandPart { BMelody = 0, BCounter, BBass, BStrings, BHorns, BDrums, numBandParts };

const char* bandPartName (int part);       // "MELODY"
const char* bandPartId (int part);         // parameter prefix, "bMel"
int bandDefaultChannel (int part);         // default MIDI channel (you can change it per part)
int bandNumStyles (int part);
const char* bandStyleName (int part, int style);
const char* bandStyleBlurb (int part, int style);

// GENRE on the BAND tab: every part's style and feel for one of VESPER's genres (Theory.h)
struct BandGenrePreset
{
    int style[6];             // per part (BandPart order)
    int lineup;               // bit per part: the parts that genre usually uses
    float density[6], complexity[6];
};
BandGenrePreset bandGenrePreset (int genre);

struct BandPartConfig
{
    bool on = false;
    int style = 0;
    uint32_t seed = 1;
    float density = 0.5f, complexity = 0.5f;
    int octave = 0;           // -2 .. +2
    float level = 0.8f;
    int channel = 1;          // MIDI channel this part plays on
    int dyn = 0;              // dynamics for phrase lines: 0 off, 1 CC1, 2 CC11, 3 both
};

struct BandConfig
{
    std::array<BandPartConfig, numBandParts> part {};
    int phraseBars = 4;       // 1, 2, 4 or 8
    float swing = 0.0f;       // 0 .. 0.5 of a step, on top of each style's own swing
};

struct Harmony
{
    Chord chord;
    Notes voicing;            // what the chord part is playing (sorted)
    int keyRoot = 0, scale = 0;
    int id = -1;              // changes every time a new chord is struck
    bool valid() const { return chord.valid(); }
};

struct BandEvent
{
    int part = 0;
    int channel = 1;
    int note = 60;            // CC number when isCC
    int velocity = 100;       // CC value when isCC
    float offset = 0.0f;      // start, in 16th steps after this step's grid time
    float length = 1.0f;      // in 16th steps; < 0 = ring until the chord changes
    bool isCC = false;
};

class Band
{
public:
    static constexpr int maxEventsPerStep = 64;

    void reset();
    // Call once per 16th step (absStep counts 16ths from the song start, or from when the band
    // started when FL is stopped). Returns how many events were written.
    int step (const BandConfig&, const Harmony&, int64_t absStep, BandEvent* out, int maxOut);

    // GM drum notes used by the drum part
    enum Drum { Kick = 36, Rim = 37, Snare = 38, Clap = 39, ClosedHat = 42, LowTom = 45, PedalHat = 44,
                OpenHat = 46, MidTom = 47, Crash = 49, HighTom = 50, Ride = 51, Tambourine = 54, Cowbell = 56,
                Conga = 63, LowConga = 64, Shaker = 70, Claves = 75 };
    static bool isDrumNote (int n);

private:
    struct PlanEv
    {
        int8_t step = 0;
        float off = 0.0f, len = 1.0f;
        int8_t accent = 0;
        int8_t spec = 0;          // what to play (see Band.cpp)
        int8_t a = 0, b = 0;      // spec arguments
    };

    struct PartState
    {
        int last = -1;            // last note played (voice leading)
        int dir = 1;              // melodic direction
        Notes voice;              // last chord voicing (strings / horns)
        int64_t planBar = -1;
        int planKey = -1;
        int count = 0;
        std::array<PlanEv, 40> plan {};
        int harmonyId = -1;
        int cycle = 0;            // ostinato position

        // phrase player (hand-written lines)
        int phrase = -1;          // index into phraseLibrary(), -1 = between phrases
        int64_t phraseStart = 0, nextPhrase = 0;
        int slot = 0, noteIdx = 0, lastIdx = -1, lastVel = 80;
        int letterA = -1;
        float ccLast = -1;
    };

    void buildPlan (int part, const BandPartConfig&, const BandConfig&, int64_t bar);
    int phraseStep (int part, int set, const BandPartConfig&, const BandConfig&, const Harmony&, int64_t absStep,
                    BandEvent* out, int maxOut);
    int pickPhrase (int set, const BandPartConfig&, const BandConfig&, uint32_t salt, int avoid) const;
    int resolve (int part, const PlanEv&, const BandPartConfig&, const Harmony&, int64_t bar, BandEvent* out, int maxOut);

    std::array<PartState, numBandParts> st {};
    int melodyNote = -1;
    float melodyLen = 0.0f, melodyOff = 0.0f;
    bool melodyHit = false;
};
} // namespace vesper
