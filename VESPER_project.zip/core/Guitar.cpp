#include "Guitar.h"

#include <algorithm>

namespace vesper
{
static const int openString[6] = { 40, 45, 50, 55, 59, 64 };   // E2 A2 D3 G3 B3 E4

int Shape::lowestFret() const
{
    int m = 99;
    for (int f : fret) if (f > 0) m = std::min (m, f);
    return m == 99 ? 0 : m;
}

int Shape::highestFret() const
{
    int m = 0;
    for (int f : fret) m = std::max (m, f);
    return m;
}

Notes shapeNotes (const Shape& s)
{
    Notes n;
    for (int i = 0; i < 6; ++i)
        if (s.fret[(size_t) i] >= 0)
            n.add (openString[i] + s.fret[(size_t) i]);
    return n;
}

static int bitCount (int m)
{
    int c = 0;
    while (m) { c += m & 1; m >>= 1; }
    return c;
}

namespace
{
struct Search
{
    int chordMask = 0, bassPc = 0, required = 0, optional = 0, colorMask = 0, minSounding = 3;
    int lo = 1, hi = 4;
    bool allowOpen = false;
    bool found = false;
    Shape best;
    Shape cur;

    void run (int s)
    {
        if (s == 6) { evaluate(); return; }
        cur.fret[(size_t) s] = -1;
        run (s + 1);
        if (allowOpen && ((chordMask >> (openString[s] % 12)) & 1))
        {
            cur.fret[(size_t) s] = 0;
            run (s + 1);
        }
        for (int f = lo; f <= hi; ++f)
        {
            if ((chordMask >> ((openString[s] + f) % 12)) & 1)
            {
                cur.fret[(size_t) s] = f;
                run (s + 1);
            }
        }
        cur.fret[(size_t) s] = -1;
    }

    void evaluate()
    {
        int sounding = 0, first = -1, last = -1;
        for (int i = 0; i < 6; ++i)
            if (cur.fret[(size_t) i] >= 0)
            {
                ++sounding;
                if (first < 0) first = i;
                last = i;
            }
        if (sounding < minSounding || last < 3) return;
        if ((openString[first] + cur.fret[(size_t) first]) % 12 != bassPc) return;

        int inner = 0;
        for (int i = first + 1; i < last; ++i)
            if (cur.fret[(size_t) i] < 0) ++inner;
        if (inner > 1) return;

        int covered = 0, fretted = 0, minF = 99, maxF = 0, opens = 0;
        for (int i = 0; i < 6; ++i)
        {
            const int f = cur.fret[(size_t) i];
            if (f < 0) continue;
            covered |= 1 << ((openString[i] + f) % 12);
            if (f == 0) { ++opens; continue; }
            ++fretted;
            minF = std::min (minF, f);
            maxF = std::max (maxF, f);
        }
        if ((covered & required) != required) return;
        if (fretted > 0 && maxF - minF > 3) return;

        int atMin = 0, barreLo = -1, barreHi = -1;
        for (int i = 0; i < 6; ++i)
            if (cur.fret[(size_t) i] == minF)
            {
                ++atMin;
                if (barreLo < 0) barreLo = i;
                barreHi = i;
            }
        // a barre can't have open or muted strings underneath it
        bool barreOk = atMin >= 2;
        for (int i = barreLo + 1; barreOk && i < barreHi; ++i)
            if (cur.fret[(size_t) i] < minF) barreOk = false;
        const int fingers = barreOk ? fretted - atMin + 1 : fretted;
        if (fingers > 4) return;

        int topMutes = 0;
        for (int i = last + 1; i < 6; ++i) ++topMutes;

        const int topPc = (openString[last] + cur.fret[(size_t) last]) % 12;
        int score = bitCount (covered & optional) * 40
                  + sounding * 20
                  - inner * 50
                  - topMutes * 12
                  - (fretted > 0 ? minF : 0) * 7
                  + opens * 12
                  - (fingers == 4 ? 30 : 0)
                  + (((colorMask >> topPc) & 1) ? 8 : 0)
                  + (first <= 1 ? 10 : 0);

        if (! found || score > best.score)
        {
            best = cur;
            best.score = score;
            found = true;
        }
    }
};
} // namespace

int findShapes (const Chord& c, Shape* out, int maxOut)
{
    if (! c.valid() || maxOut <= 0) return 0;

    const Notes iv = chordIntervals (c);
    const int rel = tonesMask (c);
    auto has = [rel] (int i) { return (rel >> i) & 1; };
    auto abs = [&c] (int r) { return 1 << ((r % 12 + c.root) % 12); };

    const int bassPc = c.bass >= 0 ? c.bass : c.root;

    int third = 0, seventh = 0, altered = 0, topExt = 0;
    if (has (4)) third = abs (4); else if (has (3)) third = abs (3); else if (has (5)) third = abs (5); else if (has (2)) third = abs (2);
    if (has (10)) seventh = abs (10); else if (has (11)) seventh = abs (11); else if (has (9)) seventh = abs (9);
    int maxIv = 0;
    for (int i = 0; i < iv.size(); ++i)
    {
        const int x = iv[i], pc = x % 12;
        if (pc == 1 || pc == 6 || pc == 8 || (pc == 3 && has (4))) altered |= abs (x);
        maxIv = std::max (maxIv, x);
    }
    if (maxIv > 12) topExt = abs (maxIv);
    const bool power = iv.size() == 2;

    const int chordMask = pcMask (c);
    const int bassBit = 1 << bassPc;
    const int rootBit = 1 << c.root;

    const int passes[4] = {
        bassBit | rootBit | third | seventh | altered | topExt | (power ? abs (7) : 0),
        bassBit | third | seventh,
        bassBit | third,
        bassBit };

    Shape found[16];
    int count = 0;

    for (int pass = 0; pass < 4 && count == 0; ++pass)
    {
        const int required = passes[pass];
        for (int p = 0; p <= 12; ++p)
        {
            Search s;
            s.chordMask = chordMask;
            s.bassPc = bassPc;
            s.required = required;
            s.optional = chordMask & ~required;
            s.colorMask = third | seventh | altered | topExt;
            s.minSounding = bitCount (chordMask) >= 4 ? 4 : 3;
            s.lo = std::max (1, p);
            s.hi = s.lo + 3;
            s.allowOpen = p <= 3;
            s.run (0);
            if (! s.found) continue;

            bool dup = false;
            for (int i = 0; i < count; ++i)
                if (found[i].fret == s.best.fret) dup = true;
            if (! dup && count < 16) found[count++] = s.best;
        }
    }

    std::stable_sort (found, found + count, [] (const Shape& a, const Shape& b) { return a.score > b.score; });
    const int n = std::min (count, maxOut);
    for (int i = 0; i < n; ++i) out[i] = found[i];
    return n;
}
} // namespace vesper
