// VESPER phrase library: hand-written instrumental lines (violin, cello, lead melodies, horn riffs,
// answer licks) stored relative to the chord, so they fit whatever you play.
//
// Phrase text, one token per note:
//   pitch : 1 3 5 7 9 11 13 (chord degree; 2 4 6 = 9 11 13)   +n / -n (scale steps from the last note)
//           c+n / c-n (semitones)   = (repeat)   @n (n semitones above the chord root)
//           b3 b5 b7 (blue notes)   r (rest)
//   octave: '  = the nearest one above the last note     ,  = the nearest one below
//   length: x 32nd  u 16th-triplet  s 16th  t 8th-triplet  S dotted 16th  e 8th  T quarter-triplet
//           E dotted 8th  q quarter  Q dotted quarter  h half  H dotted half  w whole   (join with +: h+q)
//   style : _ slur into the next note (legato)   ! short   > accent   ~ swell   ^ grace note from below
//   |     : bar line (checked)
#pragma once

#include "Theory.h"

#include <string>
#include <vector>

namespace vesper
{
enum PhraseSet
{
    PsPop = 0, PsRnb, PsJazz, PsGospel, PsLofi, PsRock, PsClassical, PsAmbient, PsLatin, PsTrap, PsCountry, PsAfro,
    PsCinematic, PsEdm,                                   // the 14 melody styles, in MELODY style order
    PsViolinLyrical, PsViolinSoul, PsViolinRuns, PsCello, PsDescant, PsAnswer, PsHorns,
    numPhraseSets
};

enum PhraseKind : int8_t { PkDegree = 0, PkStep, PkChromatic, PkRepeat, PkInterval, PkBlue, PkRest };
enum PhraseArt : uint8_t { ArtLegato = 1, ArtShort = 2, ArtAccent = 4, ArtSwell = 8, ArtGrace = 16 };

struct PhraseNote
{
    float start = 0, dur = 1;     // in 16ths from the phrase start
    PhraseKind kind = PkDegree;
    int8_t value = 1;
    int8_t octave = 0;            // -1 below, 0 nearest, +1 above the last note
    uint8_t art = 0;
};

struct Phrase
{
    int set = 0;
    int bars = 1;
    float density = 0.5f, complexity = 0.5f;
    std::vector<PhraseNote> notes;
    const char* text = "";
};

const std::vector<Phrase>& phraseLibrary();
const std::vector<int>& phrasesInSet (int set);
bool parsePhrase (const char* text, Phrase& out, std::string* error = nullptr);
const char* phraseSetName (int set);

// the phrase set a band part/style plays from (-1 = that style isn't phrase-based)
int phraseSetFor (int part, int style);

// pitch helpers shared with the band engine
int degreeInterval (int degree, const Chord&, int keyMask);
} // namespace vesper
