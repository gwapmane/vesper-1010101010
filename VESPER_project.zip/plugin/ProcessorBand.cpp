// VESPER band: plays the generated parts (core/Band) in time with FL, following the chords you play,
// each part on its own MIDI channel. Also keeps band copies of VESPER in step (LinkBus.h).
#include "PluginProcessor.h"

#include <algorithm>
#include <cmath>

using namespace vesper;

static constexpr double stepBeats = 0.25;   // the band runs on a 16th grid

//==============================================================================
// message thread
void VesperProcessor::rollBandSeed (int part)
{
    auto& r = juce::Random::getSystemRandom();
    bandSeed[(size_t) part].store ((uint32_t) r.nextInt() | 1u);
}

void VesperProcessor::applyBandGenre (int genre)
{
    const BandGenrePreset preset = bandGenrePreset (genre);
    bool anyOn = false;
    for (int part = 0; part < numBandParts; ++part)
        anyOn = anyOn || apvts.getRawParameterValue (ids::band (part, "On"))->load() > 0.5f;

    auto set = [this] (const juce::String& id, float plain)
    {
        if (auto* prm = apvts.getParameter (id))
            prm->setValueNotifyingHost (prm->convertTo0to1 (plain));
    };
    for (int part = 0; part < numBandParts; ++part)
    {
        set (ids::band (part, "Style"), (float) preset.style[part]);
        set (ids::band (part, "Dens"), preset.density[part]);
        set (ids::band (part, "Cplx"), preset.complexity[part]);
        if (! anyOn) set (ids::band (part, "On"), ((preset.lineup >> part) & 1) ? 1.0f : 0.0f);
    }
    set (ids::bandGenre, (float) genre);
}

void VesperProcessor::stopBandFromUi()
{
    int s1, z1, s2, z2;
    uiFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    auto& e = uiEvents[(size_t) (z1 > 0 ? s1 : s2)];
    e = UiEvent();
    e.type = 6;
    uiFifo.finishedWrite (1);
}

//==============================================================================
// audio thread
void VesperProcessor::readBand()
{
    linkNowMs = juce::Time::getMillisecondCounterHiRes();
    chordChannel = juce::jlimit (1, 16, (int) apvts.getRawParameterValue (ids::chordCh)->load());
    bandEnabled = apvts.getRawParameterValue (ids::bandOn)->load() > 0.5f;
    bandStopMode = (int) apvts.getRawParameterValue (ids::bandStop)->load();
    bandRoleNow = juce::jlimit (0, (int) numBandParts, (int) apvts.getRawParameterValue (ids::bandRole)->load());
    if (bandRoleNow != 0) return;   // a band copy takes everything from the main VESPER

    static const int phrases[4] = { 1, 2, 4, 8 };
    bandCfg.phraseBars = phrases[juce::jlimit (0, 3, (int) apvts.getRawParameterValue (ids::bandPhrase)->load())];
    bandCfg.swing = apvts.getRawParameterValue (ids::bandSwing)->load() / 100.0f * 0.5f;
    for (int part = 0; part < numBandParts; ++part)
    {
        const auto& prm = bandParams[(size_t) part];
        auto& pc = bandCfg.part[(size_t) part];
        pc.on = prm[0]->load() > 0.5f;
        pc.style = juce::jlimit (0, bandNumStyles (part) - 1, (int) prm[1]->load());
        pc.density = prm[2]->load();
        pc.complexity = prm[3]->load();
        pc.octave = juce::jlimit (-2, 2, (int) std::lround (prm[4]->load()));
        pc.level = prm[5]->load();
        pc.channel = juce::jlimit (1, 16, (int) std::lround (prm[6]->load()));
        pc.dyn = juce::jlimit (0, 3, (int) prm[7]->load());
        pc.seed = bandSeed[(size_t) part].load();
    }
    updateKeysSkip();
}

void VesperProcessor::updateKeysSkip()
{
    keysSkip = 0;
    const auto& d = bandCfg.part[BDrums];
    if (d.on && bandPartHere (BDrums) && d.channel != chordChannel)
        keysSkip = (uint16_t) (1u << (d.channel - 1));   // the keys sound doesn't play drum notes
}

bool VesperProcessor::bandPartHere (int part) const
{
    if (bandRoleNow == 0) return ! LinkBus::get().isClaimed (part, linkNowMs);
    return bandRoleNow - 1 == part;
}

bool VesperProcessor::anyBandPartOn() const
{
    for (const auto& pc : bandCfg.part) if (pc.on) return true;
    return false;
}

bool VesperProcessor::anyChordHeld() const
{
    for (int i = 0; i < numChordSlots; ++i)
        if (slots[(size_t) i].active && ! slots[(size_t) i].isExt) return true;
    return false;
}

double VesperProcessor::lateWindowBeats() const
{
    // a chord that lands just after a band step still makes that step (players are rarely dead on the grid)
    return juce::jmin (0.45 * stepBeats, 0.08 * bpm / 60.0);
}

void VesperProcessor::activateBandSlots()
{
    for (int part = 0; part < numBandParts; ++part)
    {
        auto& s = slots[(size_t) bandSlot (part)];
        s = Slot();
        s.active = true;
        s.source = -100 - part;
    }
}

void VesperProcessor::bandChordChanged (const Chord& chord, int pos, juce::MidiBuffer& out)
{
    if (bandRoleNow != 0 || ! chord.valid()) return;
    bandHarm.chord = chord;
    bandHarm.keyRoot = cfg.keyRoot;
    bandHarm.scale = cfg.scale;
    bandHarm.id = ++bandHarmCounter;
    bandHarmBeat = beatAt (pos);
    bandStopAt = -1;
    if (! bandRunning)
    {
        if (bandEnabled && anyBandPartOn()) startBand (pos, out);
        return;
    }
    adoptHarmony (pos, out);
}

void VesperProcessor::startBand (int pos, juce::MidiBuffer& out)
{
    for (int part = 0; part < numBandParts; ++part) clearSlotNotes (bandSlot (part), pos, out);
    band.reset();
    activateBandSlots();
    bandRunning = true;
    ++bandStarts;
    bandStopAt = -1;
    bandSynced = hostPlaying;
    const double now = beatAt (pos);
    if (bandSynced)
    {
        bandOrigin = 0;
        auto k = (int64_t) std::floor (now / stepBeats + 1e-9);
        if (now - (double) k * stepBeats > lateWindowBeats()) ++k;
        bandNextStep = k;
    }
    else
    {
        bandOrigin = now;     // FL stopped: your first chord is bar 1
        bandNextStep = 0;
    }
    bandLastStep = -1;
    bandLastStepBeat = -1e9;
    advanceBand (pos, out, true);
}

void VesperProcessor::stopBand (int pos, juce::MidiBuffer& out)
{
    for (int part = 0; part < numBandParts; ++part)
    {
        const int si = bandSlot (part);
        if (slots[(size_t) si].active) releaseSlot (si, pos, out);
    }
    if (bandRunning)
        for (int part : { (int) BStrings, (int) BHorns })
            if (bandCfg.part[(size_t) part].on)
                out.addEvent (juce::MidiMessage::controllerEvent (bandCfg.part[(size_t) part].channel, 11, 127), pos);
    bandRunning = false;
    bandStopAt = -1;
    bandLastStep = -1;
    bandLastStepBeat = -1e9;
}

void VesperProcessor::adoptHarmony (int pos, juce::MidiBuffer& out)
{
    // the old chord's notes stop where the new chord starts
    for (int part = 0; part < numBandParts; ++part)
        if (part != BDrums) clearSlotNotes (bandSlot (part), pos, out);

    // landed just after a step: play that step again with the new chord instead of waiting for the next one
    if (bandLastStep >= 0 && bandHarmBeat < bandLastStepBeat + lateWindowBeats())
        fireBandStep (bandLastStep, bandLastStepBeat, true, sampleClock + pos, out);
}

void VesperProcessor::fireBandStep (int64_t step, double stepBeat, bool pitchedOnly, int64_t minDue, juce::MidiBuffer& out)
{
    BandEvent ev[Band::maxEventsPerStep];
    const int n = band.step (bandCfg, bandHarm, step, ev, Band::maxEventsPerStep);
    uint32_t hit = 0;
    for (int i = 0; i < n; ++i)
    {
        const BandEvent& e = ev[i];
        if (pitchedOnly && (e.part == BDrums || e.isCC)) continue;
        if (! bandPartHere (e.part)) continue;
        const double t = stepBeat + e.offset * stepBeats;
        int64_t due = sampleClock + (int64_t) std::llround ((t - blockBeat) * samplesPerBeat);
        due = std::max (due, minDue);
        if (e.isCC)
        {
            const int pos = (int) juce::jlimit<int64_t> (0, juce::jmax (0, blockSamples - 1), due - sampleClock);
            out.addEvent (juce::MidiMessage::controllerEvent (e.channel, e.note, e.velocity), pos);
            continue;
        }
        const int64_t len = e.length < 0.0f ? -1 : std::max<int64_t> (1, (int64_t) std::llround (e.length * stepBeats * samplesPerBeat));
        schedule (due, e.note, e.velocity, e.channel, bandSlot (e.part), len);
        hit |= 1u << e.part;
    }
    for (int part = 0; part < numBandParts; ++part)
        if ((hit >> part) & 1u) partHits[(size_t) part].fetch_add (1, std::memory_order_relaxed);
}

void VesperProcessor::advanceBand (int upToPos, juce::MidiBuffer& out, bool inclusive)
{
    if (! bandRunning) return;
    const double limit = beatAt (upToPos) + (inclusive ? 1e-6 : 0.0);
    const int64_t minDue = sampleClock + (inclusive ? upToPos : 0);
    for (int guard = 0; guard < 64; ++guard)
    {
        const double stepBeat = bandOrigin + (double) bandNextStep * stepBeats;
        if (stepBeat >= limit) break;
        if (bandStopAt >= 0 && stepBeat >= bandStopAt - 1e-9)
        {
            stopBand (posOfBeat (stepBeat), out);
            return;
        }
        fireBandStep (bandNextStep, stepBeat, false, minDue, out);
        bandLastStep = bandNextStep;
        bandLastStepBeat = stepBeat;
        ++bandNextStep;
    }
}

void VesperProcessor::checkBandClock (int pos, juce::MidiBuffer& out)
{
    if (! bandSynced) return;
    const double now = beatAt (pos);
    const double next = bandOrigin + (double) bandNextStep * stepBeats;
    if (next < now - 0.5 || next > now + 1.0)
    {
        // FL looped or jumped: pick the band up at the new spot
        for (int part = 0; part < numBandParts; ++part) clearSlotNotes (bandSlot (part), pos, out);
        bandNextStep = (int64_t) std::ceil ((now - bandOrigin) / stepBeats - 1e-9);
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
    }
}

void VesperProcessor::bandHousekeeping (int pos, juce::MidiBuffer& out)
{
    if (! bandRunning)
    {
        // a part switched on while a chord is down: start right away
        if (bandEnabled && anyBandPartOn() && anyChordHeld() && bandHarm.valid()) startBand (pos, out);
        return;
    }
    if (! bandEnabled || ! anyBandPartOn())
    {
        stopBand (pos, out);
        return;
    }

    if (bandSynced != hostPlaying)
    {
        if (! hostPlaying && bandStopMode == 2)
        {
            stopBand (pos, out);   // NEVER mode stops with FL
            return;
        }
        bandSynced = hostPlaying;
        const double now = beatAt (pos);
        if (bandSynced) { bandOrigin = 0; bandNextStep = (int64_t) std::ceil (now / stepBeats - 1e-9); }
        else            { bandOrigin = now; bandNextStep = 0; }
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
    }
    else checkBandClock (pos, out);

    // parts switched off (or taken over by a band copy) go quiet
    for (int part = 0; part < numBandParts; ++part)
        if (! (bandCfg.part[(size_t) part].on && bandPartHere (part)))
        {
            const auto& s = slots[(size_t) bandSlot (part)];
            if (! s.sent.empty()) clearSlotNotes (bandSlot (part), pos, out);
        }

    if (anyChordHeld()) { bandStopAt = -1; return; }
    if (bandStopAt >= 0 || bandStopMode == 2) return;
    const double now = beatAt (pos);
    if (bandStopMode == 0)
        bandStopAt = now + 0.15 * bpm / 60.0;   // a short grace, so moving between chords doesn't stop the band
    else
    {
        const double bars = std::ceil ((now - bandOrigin) / 4.0 - 1e-9);
        bandStopAt = bandOrigin + bars * 4.0;
        if (bandStopAt < now + 0.01) bandStopAt = now + 0.15 * bpm / 60.0;
    }
}

//==============================================================================
// link between VESPER copies
void VesperProcessor::publishLink()
{
    LinkSnapshot s;
    s.leaderId = linkId;
    s.wallMs = linkNowMs;
    s.cfg = bandCfg;
    s.harm = bandHarm;
    s.harmBeat = bandHarmBeat;
    s.running = bandRunning;
    s.starts = bandStarts;
    s.synced = bandSynced;
    s.origin = bandOrigin;
    s.clock = sampleClock;
    s.beat = blockBeat;
    s.spb = samplesPerBeat;
    LinkBus::get().publish (s);
}

void VesperProcessor::followLeader (juce::MidiBuffer& out)
{
    const int part = bandRoleNow - 1;
    LinkSnapshot L;
    auto& bus = LinkBus::get();
    if (! bus.read (L) || linkNowMs - L.wallMs > 1000.0 || L.leaderId == linkId)
    {
        followState.store (2);
        if (bandRunning) stopBand (0, out);
        return;
    }
    followState.store (1);
    bus.claim (part, linkNowMs + 600.0);
    bandCfg = L.cfg;
    updateKeysSkip();

    // where the leader's band clock is right now, in our own clock
    const double obs = (double) (L.clock - sampleClock);
    if (L.leaderId != linkLeaderSeen)
    {
        linkLeaderSeen = L.leaderId;
        linkDeltaBest = obs;
        linkStarts = 0;
        linkHarmId = -1;
    }
    linkDeltaBest = std::max (linkDeltaBest, obs);   // same audio cycle = the largest difference we see
    const double offset = (L.synced && hostPlaying) ? 0.0
                        : (L.beat + ((double) sampleClock + linkDeltaBest - (double) L.clock) / L.spb) - blockBeat;

    const bool wanted = L.running && L.cfg.part[(size_t) part].on;
    if (! wanted)
    {
        if (bandRunning) stopBand (0, out);
        linkStarts = L.starts;
        linkHarmId = L.harm.id;
        return;
    }

    const double now = blockBeat;
    auto anchor = [&]
    {
        bandSynced = L.synced;
        bandOrigin = L.origin - offset;
        auto k = (int64_t) std::floor ((now - bandOrigin) / stepBeats + 1e-9);
        if (now - (bandOrigin + (double) k * stepBeats) > lateWindowBeats()) ++k;
        bandNextStep = bandSynced ? k : std::max<int64_t> (0, k);
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
        linkOriginSeen = L.origin;
        linkSyncedSeen = L.synced;
    };

    if (! bandRunning || L.starts != linkStarts)
    {
        if (bandRunning) stopBand (0, out);
        band.reset();
        activateBandSlots();
        bandRunning = true;
        linkStarts = L.starts;
        bandHarm = L.harm;
        linkHarmId = L.harm.id;
        bandHarmBeat = L.harmBeat - offset;
        anchor();
        advanceBand (0, out, true);   // the leader's first step, if we're a moment behind it
        return;
    }

    if (L.synced != linkSyncedSeen || std::abs (L.origin - linkOriginSeen) > 1e-9)
        anchor();                         // FL started or stopped
    else
        checkBandClock (0, out);

    if (L.harm.id != linkHarmId)
    {
        linkHarmId = L.harm.id;
        bandHarm = L.harm;
        bandHarmBeat = L.harmBeat - offset;
        adoptHarmony (0, out);
    }
}
