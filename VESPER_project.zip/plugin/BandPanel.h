#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "Widgets.h"

// The BAND tab: melody, counter-melody, bass, strings, horns and drums that play along with your
// chords, each on its own MIDI channel.
class BandPanel : public juce::Component, private juce::Timer
{
public:
    explicit BandPanel (EditorContext& c);
    ~BandPanel() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct PartDrag : public juce::Component, public juce::SettableTooltipClient
    {
        PartDrag (EditorContext& c, int p) : ctx (c), part (p) {}
        void paint (juce::Graphics&) override;
        void mouseDrag (const juce::MouseEvent&) override;
        void mouseUp (const juce::MouseEvent&) override;
        juce::File exportPart();
        EditorContext& ctx;
        int part;
        bool started = false;
    };

    struct Strip
    {
        std::unique_ptr<juce::TextButton> on, dice;
        std::unique_ptr<juce::ComboBox> style, channel, octave, dyn;
        std::unique_ptr<juce::Slider> density, complexity, level;
        std::unique_ptr<PartDrag> drag;
        uint32_t lastHits = 0;
        float glow = 0.0f;
    };

    void timerCallback() override;
    juce::Rectangle<int> stripBounds (int part) const;
    void setParam (const juce::String& id, float value);
    bool anyPartOn() const;

    EditorContext& ctx;
    std::array<Strip, vesper::numBandParts> strips;
    juce::TextButton bandOnBtn { "BAND ON" }, diceAllBtn { "DICE ALL" }, stopBtn { "STOP" };
    juce::ComboBox genreBox, phraseBox, stopModeBox, roleBox, chordChBox;
    juce::Slider swingKnob;
    int lastGenre = -1, lastFollow = -1;
    bool lastPlaying = false, lastAnyOn = false;
    std::array<uint32_t, vesper::numBandParts> lastSeed {};

    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
};
