#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "Widgets.h"

// The STYLE tab: every playing style as an on/off switch, plus the upper-extension pad.
class StylePanel : public juce::Component, private juce::Timer
{
public:
    explicit StylePanel (EditorContext& c);
    ~StylePanel() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct ExtPad : public juce::Component, public juce::SettableTooltipClient
    {
        explicit ExtPad (EditorContext& c) : ctx (c) {}
        void paint (juce::Graphics&) override;
        void mouseDown (const juce::MouseEvent&) override { pressed = true; ctx.proc().uiExt (true); repaint(); }
        void mouseUp (const juce::MouseEvent&) override { pressed = false; ctx.proc().uiExt (false); repaint(); }
        EditorContext& ctx;
        bool pressed = false;
    };

    void timerCallback() override;
    void showTriggerMenu();
    void setParam (const char* id, float value);

    EditorContext& ctx;
    juce::OwnedArray<juce::TextButton> rhythmBtns, feelBtns, timingBtns;
    juce::ComboBox rateBox, multiBox, extTypeBox, extModeBox, extRateBox;
    juce::Slider swingKnob;
    juce::ToggleButton extStylesBtn { "STYLES ON EXT" }, extLatchBtn { "LATCH" };
    juce::TextButton triggerBtn { "SET BUTTON" }, allOffBtn { "ALL OFF" };
    ExtPad extPad;
    uint32_t lastLearn = 0;
    bool lastExtOn = false, lastArmed = false;
    int lastRhythmShown = -2;

    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAtt;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> swingAtt;
};
