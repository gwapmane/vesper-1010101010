#include "BandPanel.h"

using namespace vesper;

// layout (inside the 1124 x 266 content area)
static constexpr int stripTop = 48, stripH = 70, stripGapY = 3, colW = 556, colGap = 12;

BandPanel::BandPanel (EditorContext& c) : ctx (c)
{
    auto& p = ctx.proc();
    auto& apvts = p.apvts;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;

    auto knob = [this] (juce::Slider& s, const juce::String& tip)
    {
        s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        s.setTooltip (tip);
        addAndMakeVisible (s);
    };

    // ---- top row
    bandOnBtn.setClickingTogglesState (true);
    bandOnBtn.setTooltip ("Master switch for the band");
    addAndMakeVisible (bandOnBtn);
    buttonAtt.push_back (std::make_unique<BA> (apvts, ids::bandOn, bandOnBtn));

    for (int g = 0; g < numGenres; ++g) genreBox.addItem (genreName (g), g + 1);
    genreBox.setTextWhenNothingSelected ("PICK A GENRE");
    genreBox.setTooltip ("Sets every part to that genre's style. If no parts are on yet, it also turns on the usual lineup");
    genreBox.onChange = [this]
    {
        const int g = genreBox.getSelectedId() - 1;
        if (g < 0) return;
        ctx.proc().applyBandGenre (g);
        lastGenre = g;
        repaint();
    };
    addAndMakeVisible (genreBox);

    phraseBox.addItemList ({ "1 bar", "2 bars", "4 bars", "8 bars" }, 1);
    phraseBox.setTooltip ("How long a phrase is before the parts come back around (they repeat with small changes, like a real hook)");
    addAndMakeVisible (phraseBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::bandPhrase, phraseBox));

    knob (swingKnob, "Extra swing for the whole band (on top of each style's own feel)");
    swingKnob.onValueChange = [this] { repaint (380, 0, 100, 44); };
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::bandSwing, swingKnob));

    stopModeBox.addItemList ({ "When you let go", "At the end of the bar", "Never (until FL stops)" }, 1);
    stopModeBox.setTooltip ("When the band stops after you let go of the chord");
    addAndMakeVisible (stopModeBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::bandStop, stopModeBox));

    roleBox.addItem ("EVERYTHING", 1);
    for (int part = 0; part < numBandParts; ++part) roleBox.addItem (juce::String ("ONLY ") + bandPartName (part), part + 2);
    roleBox.setTooltip ("For separate instruments: add another VESPER, set this to ONLY BASS (etc.) and give it its own MIDI port. "
                        "It plays that part from the main VESPER, which then leaves it out");
    roleBox.onChange = [this] { repaint(); };
    addAndMakeVisible (roleBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::bandRole, roleBox));

    for (int ch = 1; ch <= 16; ++ch) chordChBox.addItem ("CH " + juce::String (ch), ch);
    chordChBox.setTooltip ("MIDI channel for VESPER's chords");
    addAndMakeVisible (chordChBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::chordCh, chordChBox));

    diceAllBtn.setTooltip ("New lines for every part that's on (same styles, new ideas)");
    diceAllBtn.onClick = [this]
    {
        for (int part = 0; part < numBandParts; ++part)
            if (strips[(size_t) part].on->getToggleState()) ctx.proc().rollBandSeed (part);
        repaint();
    };
    addAndMakeVisible (diceAllBtn);

    stopBtn.setTooltip ("Stop the band now");
    stopBtn.onClick = [this] { ctx.proc().stopBandFromUi(); };
    addAndMakeVisible (stopBtn);

    // ---- part strips
    for (int part = 0; part < numBandParts; ++part)
    {
        auto& s = strips[(size_t) part];
        s.on = std::make_unique<juce::TextButton> (bandPartName (part));
        s.on->setClickingTogglesState (true);
        s.on->setTooltip (juce::String ("Turn the ") + juce::String (bandPartName (part)).toLowerCase() + " on or off");
        s.on->getProperties().set ("radius", 4.0);
        addAndMakeVisible (*s.on);
        buttonAtt.push_back (std::make_unique<BA> (apvts, ids::band (part, "On"), *s.on));

        s.style = std::make_unique<juce::ComboBox>();
        for (int st = 0; st < bandNumStyles (part); ++st) s.style->addItem (bandStyleName (part, st), st + 1);
        s.style->setTooltip ("Style for this part");
        s.style->onChange = [this] { repaint(); };
        addAndMakeVisible (*s.style);
        comboAtt.push_back (std::make_unique<CA> (apvts, ids::band (part, "Style"), *s.style));

        s.dice = std::make_unique<juce::TextButton> ("DICE");
        s.dice->setTooltip ("A new line in the same style. Each roll is one of billions");
        s.dice->onClick = [this, part] { ctx.proc().rollBandSeed (part); repaint(); };
        addAndMakeVisible (*s.dice);

        s.channel = std::make_unique<juce::ComboBox>();
        for (int ch = 1; ch <= 16; ++ch) s.channel->addItem ("CH " + juce::String (ch), ch);
        s.channel->setTooltip ("MIDI channel this part plays on. Point an instrument (or an Omnisphere multi part) at it");
        addAndMakeVisible (*s.channel);
        comboAtt.push_back (std::make_unique<CA> (apvts, ids::band (part, "Ch"), *s.channel));

        s.octave = std::make_unique<juce::ComboBox>();
        s.octave->addItemList ({ "OCT -2", "OCT -1", "OCT 0", "OCT +1", "OCT +2" }, 1);
        s.octave->setTooltip ("Move the part up or down an octave");
        addAndMakeVisible (*s.octave);
        comboAtt.push_back (std::make_unique<CA> (apvts, ids::band (part, "Oct"), *s.octave));

        s.dyn = std::make_unique<juce::ComboBox>();
        s.dyn->addItemList ({ "DYN OFF", "CC1", "CC11", "CC1+11" }, 1);
        s.dyn->setTooltip ("Dynamics for the hand-written lines: sends swells and phrasing as CC. "
                           "Orchestral string libraries (Kontakt, Spitfire...) want CC1. Synths like Omnisphere: CC11 (expression)");
        addAndMakeVisible (*s.dyn);
        comboAtt.push_back (std::make_unique<CA> (apvts, ids::band (part, "Dyn"), *s.dyn));

        s.density = std::make_unique<juce::Slider>();
        s.complexity = std::make_unique<juce::Slider>();
        s.level = std::make_unique<juce::Slider>();
        knob (*s.density, "BUSY: how many notes. Low = sparse and laid back, high = busy");
        knob (*s.complexity, "COMPLEX: how adventurous. Low = simple and safe, high = runs, leaps, fills, chromatic notes");
        knob (*s.level, "LEVEL: how hard this part plays (velocity)");
        sliderAtt.push_back (std::make_unique<SA> (apvts, ids::band (part, "Dens"), *s.density));
        sliderAtt.push_back (std::make_unique<SA> (apvts, ids::band (part, "Cplx"), *s.complexity));
        sliderAtt.push_back (std::make_unique<SA> (apvts, ids::band (part, "Lvl"), *s.level));

        s.drag = std::make_unique<PartDrag> (ctx, part);
        s.drag->setTooltip ("Record (AUTO REC or REC), then drag just this part onto its own instrument's channel");
        addAndMakeVisible (*s.drag);
        lastSeed[(size_t) part] = p.bandSeed[(size_t) part].load();
    }

    lastGenre = (int) apvts.getRawParameterValue (ids::bandGenre)->load();
    lastAnyOn = anyPartOn();
    genreBox.setSelectedId (lastAnyOn ? lastGenre + 1 : 0, juce::dontSendNotification);
    startTimerHz (20);
}

BandPanel::~BandPanel() { stopTimer(); }

bool BandPanel::anyPartOn() const
{
    for (int part = 0; part < numBandParts; ++part)
        if (ctx.proc().apvts.getRawParameterValue (ids::band (part, "On"))->load() > 0.5f) return true;
    return false;
}

void BandPanel::setParam (const juce::String& id, float value)
{
    if (auto* prm = ctx.proc().apvts.getParameter (id))
        prm->setValueNotifyingHost (prm->convertTo0to1 (value));
}

juce::Rectangle<int> BandPanel::stripBounds (int part) const
{
    const int col = part % 2, row = part / 2;
    return { col * (colW + colGap), stripTop + row * (stripH + stripGapY), colW, stripH };
}

void BandPanel::resized()
{
    bandOnBtn.setBounds (0, 14, 84, 24);
    genreBox.setBounds (92, 14, 196, 24);
    phraseBox.setBounds (296, 14, 80, 24);
    swingKnob.setBounds (384, 8, 34, 34);
    stopModeBox.setBounds (476, 14, 170, 24);
    roleBox.setBounds (654, 14, 150, 24);
    chordChBox.setBounds (812, 14, 72, 24);
    diceAllBtn.setBounds (892, 14, 80, 24);
    stopBtn.setBounds (980, 14, 60, 24);

    for (int part = 0; part < numBandParts; ++part)
    {
        auto& s = strips[(size_t) part];
        const auto r = stripBounds (part);
        const int x = r.getX(), y = r.getY();
        s.on->setBounds (x + 22, y + 6, 96, 24);
        s.style->setBounds (x + 124, y + 6, 166, 24);
        s.dice->setBounds (x + 296, y + 6, 48, 24);
        s.channel->setBounds (x + 350, y + 6, 70, 24);
        s.octave->setBounds (x + 426, y + 6, 66, 24);
        s.drag->setBounds (x + 498, y + 6, 54, 24);
        s.density->setBounds (x + 8, y + 35, 30, 30);
        s.complexity->setBounds (x + 88, y + 35, 30, 30);
        s.level->setBounds (x + 182, y + 35, 30, 30);
        s.dyn->setBounds (x + 472, y + 39, 80, 22);
    }
}

void BandPanel::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    drawCaption (g, { 0.0f, 0.0f, 84.0f, 12.0f }, "BAND", t);
    drawCaption (g, { 92.0f, 0.0f, 196.0f, 12.0f }, "GENRE", t);
    drawCaption (g, { 296.0f, 0.0f, 80.0f, 12.0f }, "PHRASE", t);
    drawCaption (g, { 420.0f, 0.0f, 54.0f, 12.0f }, "SWING", t);
    g.setFont (uiFont (11.0f, true));
    g.setColour (t.text);
    g.drawText (juce::String (juce::roundToInt (swingKnob.getValue())) + "%", juce::Rectangle<float> (420.0f, 18.0f, 54.0f, 14.0f), juce::Justification::centredLeft);
    drawCaption (g, { 476.0f, 0.0f, 170.0f, 12.0f }, "STOPS", t);
    drawCaption (g, { 654.0f, 0.0f, 150.0f, 12.0f }, "THIS VESPER PLAYS", t);
    drawCaption (g, { 812.0f, 0.0f, 72.0f, 12.0f }, "CHORDS", t);

    // playing light
    const bool playing = p.bandPlaying.load();
    const juce::Rectangle<float> led (1050.0f, 20.0f, 10.0f, 10.0f);
    g.setColour (playing ? t.home : t.cardDark);
    g.fillEllipse (led);
    g.setColour (t.panelEdge);
    g.drawEllipse (led, 1.0f);
    g.setFont (uiFont (10.5f, true));
    const bool anyOn = anyPartOn();
    g.setColour (playing ? t.text : (anyOn ? t.dim : t.color));
    g.drawFittedText (playing ? "PLAYING" : (anyOn ? "PLAY A CHORD" : "ALL PARTS OFF"), juce::Rectangle<int> (1064, 8, 60, 34),
                      juce::Justification::centredLeft, 2);

    if (! anyOn && roleBox.getSelectedId() <= 1)
    {
        g.setFont (uiFont (10.5f, true));
        g.setColour (t.color);
        g.drawText ("Every part is off: pick a GENRE, or click a part's name (MELODY, BASS, DRUMS...) to turn it on",
                    juce::Rectangle<float> (0.0f, 38.0f, (float) getWidth(), 10.0f), juce::Justification::centredLeft);
    }

    const int role = roleBox.getSelectedId() - 1;
    for (int part = 0; part < numBandParts; ++part)
    {
        const auto& s = strips[(size_t) part];
        const auto r = stripBounds (part).toFloat();
        const bool on = s.on->getToggleState();
        g.setColour (on ? t.card : t.cardDark);
        g.fillRoundedRectangle (r, 7.0f);
        g.setColour (on ? t.panelEdge.brighter (0.2f) : t.panelEdge);
        g.drawRoundedRectangle (r.reduced (0.5f), 7.0f, 1.0f);

        // activity light
        const juce::Rectangle<float> dot (r.getX() + 7.0f, r.getY() + 13.0f, 9.0f, 9.0f);
        g.setColour (t.cardDark.interpolatedWith (t.home, on ? 0.25f + 0.75f * s.glow : 0.0f));
        g.fillEllipse (dot);
        g.setColour (t.panelEdge);
        g.drawEllipse (dot, 1.0f);

        g.setFont (uiFont (9.5f, true));
        g.setColour (t.dim);
        g.drawText ("BUSY", juce::Rectangle<float> (r.getX() + 40.0f, r.getY() + 43.0f, 46.0f, 14.0f), juce::Justification::centredLeft);
        g.drawText ("COMPLEX", juce::Rectangle<float> (r.getX() + 120.0f, r.getY() + 43.0f, 60.0f, 14.0f), juce::Justification::centredLeft);
        g.drawText ("LEVEL", juce::Rectangle<float> (r.getX() + 214.0f, r.getY() + 43.0f, 40.0f, 14.0f), juce::Justification::centredLeft);

        const int style = juce::jmax (0, s.style->getSelectedId() - 1);
        juce::String blurb = bandStyleBlurb (part, style);
        blurb << "  -  line #" << (int) (p.bandSeed[(size_t) part].load() % 100000u);
        if (role > 0 && role - 1 != part) blurb = "Played by the main VESPER";
        g.setFont (uiFont (10.5f));
        g.setColour (on ? t.text.withAlpha (0.8f) : t.dim);
        g.drawFittedText (blurb, juce::Rectangle<int> ((int) r.getX() + 258, (int) r.getY() + 36, colW - 350, 30),
                          juce::Justification::centredLeft, 2, 0.85f);
    }

    // a band copy: explain what it's doing
    if (role > 0)
    {
        const auto area = juce::Rectangle<float> (0.0f, (float) stripTop, (float) getWidth(), (float) (getHeight() - stripTop));
        g.setColour (t.bgBottom.withAlpha (0.82f));
        g.fillRoundedRectangle (area, 8.0f);
        const int f = p.followState.load();
        const juce::String part = bandPartName (role - 1);
        juce::String text;
        if (f == 2)
            text = "This VESPER is set to play ONLY " + part + ", but there's no main VESPER playing yet.\n"
                   "Add a VESPER set to EVERYTHING (your main one), turn " + part + " on there, and play chords on it.";
        else
            text = "BAND COPY: playing only the " + part + " from your main VESPER, in sync.\n"
                   "Change the band (styles, DICE, channels) on the main VESPER. The main VESPER leaves " + part + " out.\n"
                   "Give this one its own MIDI output port (FL gear icon > MIDI > Output port) and set your " + part.toLowerCase()
                   + " instrument's input port to the same number.";
        g.setFont (uiFont (13.0f, true));
        g.setColour (t.text);
        g.drawFittedText (text, area.reduced (30.0f, 10.0f).toNearestInt(), juce::Justification::centred, 5);
    }
}

void BandPanel::timerCallback()
{
    auto& p = ctx.proc();
    bool dirty = false;
    for (int part = 0; part < numBandParts; ++part)
    {
        auto& s = strips[(size_t) part];
        const auto hits = p.partHits[(size_t) part].load();
        if (hits != s.lastHits) { s.lastHits = hits; s.glow = 1.0f; dirty = true; }
        else if (s.glow > 0.0f) { s.glow = juce::jmax (0.0f, s.glow - 0.2f); dirty = true; }
        const auto seed = p.bandSeed[(size_t) part].load();
        if (seed != lastSeed[(size_t) part]) { lastSeed[(size_t) part] = seed; dirty = true; }
    }
    const int genre = (int) p.apvts.getRawParameterValue (ids::bandGenre)->load();
    const bool anyOn = anyPartOn();
    if (genre != lastGenre || anyOn != lastAnyOn)
    {
        lastGenre = genre;
        lastAnyOn = anyOn;
        // nothing on yet: show PICK A GENRE, so choosing any genre (even the first one) starts the band
        genreBox.setSelectedId (anyOn ? genre + 1 : 0, juce::dontSendNotification);
        dirty = true;
    }
    const bool playing = p.bandPlaying.load();
    const int follow = p.followState.load();
    if (playing != lastPlaying || follow != lastFollow) { lastPlaying = playing; lastFollow = follow; dirty = true; }
    if (dirty) repaint();
}

//==============================================================================
juce::File BandPanel::PartDrag::exportPart()
{
    auto& p = ctx.proc();
    const int ch = (int) p.apvts.getRawParameterValue (ids::band (part, "Ch"))->load();
    return p.exportRecording (ch, juce::String (bandPartName (part)).toLowerCase());
}

void BandPanel::PartDrag::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const bool have = ctx.proc().recordedNotes() > 0;
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    g.setColour (have ? t.cardHi : t.cardDark);
    g.fillRoundedRectangle (r, 5.0f);
    juce::Path border, dashed;
    border.addRoundedRectangle (r, 5.0f);
    const float dashes[] = { 3.0f, 3.0f };
    juce::PathStrokeType (1.0f).createDashedStroke (dashed, border, dashes, 2);
    g.setColour (have ? t.home : t.faint);
    g.fillPath (dashed);
    g.setFont (uiFont (10.5f, have));
    g.setColour (have ? t.text : t.dim);
    g.drawText ("DRAG", getLocalBounds(), juce::Justification::centred);
}

void BandPanel::PartDrag::mouseDrag (const juce::MouseEvent& e)
{
    if (started || e.getDistanceFromDragStart() < 5 || ctx.proc().recordedNotes() == 0) return;
    started = true;
    const auto f = exportPart();
    if (f.existsAsFile())
        juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
}

void BandPanel::PartDrag::mouseUp (const juce::MouseEvent&)
{
    if (! started && ctx.proc().recordedNotes() > 0)
    {
        const auto f = exportPart();
        if (f.existsAsFile())
        {
            auto dir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER");
            dir.createDirectory();
            auto dest = dir.getNonexistentChildFile (f.getFileNameWithoutExtension(), ".mid");
            if (f.copyFileTo (dest)) dest.revealToUser();
        }
    }
    started = false;
}
