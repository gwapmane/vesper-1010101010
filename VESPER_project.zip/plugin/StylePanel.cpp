#include "StylePanel.h"

using namespace vesper;

// layout (inside the 1124 x 266 content area)
static const juce::Rectangle<int> rhythmArea (0, 18, 556, 152);
static constexpr int feelX = 568, feelW = 238, extX = 818;

StylePanel::StylePanel (EditorContext& c) : ctx (c), extPad (c)
{
    auto& apvts = ctx.proc().apvts;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    auto makeToggle = [this, &apvts] (juce::OwnedArray<juce::TextButton>& list, const StyleInfo& info, int partner,
                                      const char* partnerId)
    {
        auto* b = list.add (new juce::TextButton (info.name));
        b->setClickingTogglesState (true);
        b->setTooltip (info.blurb);
        b->getProperties().set ("radius", 4.0);
        addAndMakeVisible (b);
        buttonAtt.push_back (std::make_unique<BA> (apvts, info.id, *b));
        if (partner >= 0)
        {
            const juce::String pid (partnerId);
            b->onClick = [this, b, pid] { if (b->getToggleState()) setParam (pid.toRawUTF8(), 0.0f); };
        }
    };

    for (int r = 0; r < numRhythms; ++r) makeToggle (rhythmBtns, rhythmInfo (r), -1, nullptr);
    for (int f = 0; f < numFeels; ++f)
    {
        const int p = feelPartner (f);
        makeToggle (feelBtns, feelInfo (f), p, p >= 0 ? feelInfo (p).id : nullptr);
    }
    for (int t = 0; t < numTimings; ++t)
    {
        const int p = timingPartner (t);
        makeToggle (timingBtns, timingInfo (t), p, p >= 0 ? timingInfo (p).id : nullptr);
    }

    rateBox.addItem ("Style default", 1);
    for (int r = 0; r < numRates; ++r) rateBox.addItem (rateName (r), r + 2);
    multiBox.addItemList ({ "Take turns", "Random" }, 1);
    for (int t = 0; t < numExtTypes; ++t) extTypeBox.addItem (extTypeName (t), t + 1);
    for (int m = 0; m < numExtModes; ++m) extModeBox.addItem (extModeName (m), m + 1);
    for (int r = 0; r < numRates; ++r) extRateBox.addItem (rateName (r), r + 1);
    rateBox.setTooltip ("How fast the playing styles move. Style default = each style's natural speed");
    multiBox.setTooltip ("When several styles are on: each new chord takes the next one, or a random one");
    extTypeBox.setTooltip ("Which notes the extension adds on top of the chord");
    extModeBox.setTooltip ("How the extension plays: held, or in time with FL's tempo");
    extRateBox.setTooltip ("Speed of the extension when it plays in time");
    for (auto* b : { &rateBox, &multiBox, &extTypeBox, &extModeBox, &extRateBox }) addAndMakeVisible (b);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::rate, rateBox));
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::multi, multiBox));
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::extType, extTypeBox));
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::extMode, extModeBox));
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::extRate, extRateBox));
    extModeBox.onChange = [this] { repaint(); };
    extTypeBox.onChange = [this] { repaint(); };

    swingKnob.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    swingKnob.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    swingKnob.setTooltip ("How much the off-beats swing (when SWING is on)");
    swingKnob.onValueChange = [this] { repaint (rhythmArea.getX(), 180, 400, 60); };
    addAndMakeVisible (swingKnob);
    swingAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, ids::swing, swingKnob);

    extStylesBtn.setTooltip ("ON: the extension uses all your playing styles too. OFF: it plays its own way (the HOW menu)");
    extLatchBtn.setTooltip ("ON: tap once to turn the extension on, tap again to turn it off");
    addAndMakeVisible (extStylesBtn);
    addAndMakeVisible (extLatchBtn);
    buttonAtt.push_back (std::make_unique<BA> (apvts, ids::extStyles, extStylesBtn));
    buttonAtt.push_back (std::make_unique<BA> (apvts, ids::extLatch, extLatchBtn));

    triggerBtn.onClick = [this] { showTriggerMenu(); };
    triggerBtn.setTooltip ("Pick the key, pad or pedal on your controller that plays the extension");
    addAndMakeVisible (triggerBtn);

    allOffBtn.setTooltip ("Turn every playing style off (plain chords)");
    allOffBtn.onClick = [this]
    {
        for (int r = 0; r < numRhythms; ++r) setParam (rhythmInfo (r).id, 0.0f);
        for (int f = 0; f < numFeels; ++f) setParam (feelInfo (f).id, 0.0f);
        for (int t = 0; t < numTimings; ++t) setParam (timingInfo (t).id, 0.0f);
    };
    addAndMakeVisible (allOffBtn);

    extPad.setTooltip ("Hold a chord, then hold this (or your mapped button) for the upper extension");
    addAndMakeVisible (extPad);
    lastLearn = ctx.proc().learnCount.load();
    startTimerHz (15);
}

StylePanel::~StylePanel() { stopTimer(); }

void StylePanel::setParam (const char* id, float value)
{
    if (auto* p = ctx.proc().apvts.getParameter (id))
        p->setValueNotifyingHost (p->convertTo0to1 (value));
}

void StylePanel::resized()
{
    const int cols = 5, gap = 5;
    const int bw = (rhythmArea.getWidth() - gap * (cols - 1)) / cols, bh = 26;
    for (int i = 0; i < rhythmBtns.size(); ++i)
        rhythmBtns[i]->setBounds (rhythmArea.getX() + (i % cols) * (bw + gap), rhythmArea.getY() + (i / cols) * (bh + gap), bw, bh);

    rateBox.setBounds (0, 196, 116, 24);
    swingKnob.setBounds (128, 186, 36, 36);
    multiBox.setBounds (238, 196, 116, 24);
    allOffBtn.setBounds (366, 196, 80, 24);

    const int fw = (feelW - gap) / 2, fh = 24;
    for (int i = 0; i < feelBtns.size(); ++i)
        feelBtns[i]->setBounds (feelX + (i % 2) * (fw + gap), 18 + (i / 2) * (fh + gap), fw, fh);
    for (int i = 0; i < timingBtns.size(); ++i)
        timingBtns[i]->setBounds (feelX + (i % 2) * (fw + gap), 182 + (i / 2) * (fh + 4), fw, fh);

    const int extW = getWidth() - extX;
    extPad.setBounds (extX, 18, 112, 96);
    triggerBtn.setBounds (extX + 122, 50, extW - 122, 24);
    extLatchBtn.setBounds (extX + 122, 84, 86, 24);
    extTypeBox.setBounds (extX, 136, 150, 24);
    extModeBox.setBounds (extX + 156, 136, extW - 156, 24);
    extRateBox.setBounds (extX, 180, 84, 24);
    extStylesBtn.setBounds (extX + 92, 180, extW - 92, 24);
}

void StylePanel::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    drawCaption (g, { 0.0f, 0.0f, 556.0f, 14.0f }, "PLAYING STYLE  -  IN TIME WITH FL  -  TURN ON AS MANY AS YOU LIKE", t);
    drawCaption (g, { 0.0f, 182.0f, 116.0f, 12.0f }, "SPEED", t);
    drawCaption (g, { 168.0f, 190.0f, 60.0f, 12.0f }, "SWING", t);
    g.setFont (uiFont (11.0f, true));
    g.setColour (t.text);
    g.drawText (juce::String (juce::roundToInt (swingKnob.getValue())) + "%", juce::Rectangle<float> (168.0f, 204.0f, 60.0f, 14.0f), juce::Justification::centredLeft);
    drawCaption (g, { 238.0f, 182.0f, 120.0f, 12.0f }, "SEVERAL ON", t);

    // what's playing
    int active = 0;
    for (int r = 0; r < numRhythms; ++r) if (rhythmBtns[r]->getToggleState()) ++active;
    const auto& played = ctx.lastPlayed();
    juce::String now;
    if (active == 0) now = "All styles off: chords play plain (block). Turn on any style above.";
    else if (played.rhythm >= 0) now = "Last chord played: " + juce::String (rhythmInfo (played.rhythm).name)
                                     + (active > 1 ? juce::String ("  -  ") + juce::String (active) + " styles on, they take turns per chord" : juce::String());
    else now = juce::String (active) + (active == 1 ? " style on - play a chord" : " styles on - play chords to hear them take turns");
    g.setFont (uiFont (11.0f));
    g.setColour (t.dim);
    g.drawFittedText (now, juce::Rectangle<int> (0, 232, 556, 30), juce::Justification::topLeft, 2);

    drawCaption (g, { (float) feelX, 0.0f, (float) feelW, 14.0f }, "FEEL", t);
    drawCaption (g, { (float) feelX, 166.0f, (float) feelW, 14.0f }, "TIMING", t);

    g.setColour (t.panelEdge);
    g.drawVerticalLine (feelX - 7, 0.0f, (float) getHeight());
    g.drawVerticalLine (extX - 6, 0.0f, (float) getHeight());

    const float extW = (float) (getWidth() - extX);
    drawCaption (g, { (float) extX, 0.0f, extW, 14.0f }, "UPPER EXTENSION", t);
    drawCaption (g, { (float) extX + 122.0f, 18.0f, extW - 122.0f, 12.0f }, "BUTTON", t);
    g.setFont (uiFont (12.0f, true));
    g.setColour (p.learnArmed.load() ? t.color : t.text);
    g.drawFittedText (p.learnArmed.load() ? juce::String ("Press a key, pad or pedal...") : p.extTriggerName(),
                      juce::Rectangle<int> (extX + 122, 30, (int) extW - 122, 18), juce::Justification::centredLeft, 1);
    drawCaption (g, { (float) extX, 122.0f, 150.0f, 12.0f }, "ADD", t);
    drawCaption (g, { (float) extX + 156.0f, 122.0f, extW - 156.0f, 12.0f }, "HOW", t);
    drawCaption (g, { (float) extX, 166.0f, 84.0f, 12.0f }, "SPEED", t);
    g.setFont (uiFont (10.5f));
    g.setColour (t.dim);
    const int mode = extModeBox.getSelectedId() - 1;
    g.drawFittedText (juce::String (extModeBlurb (juce::jmax (0, mode))) + ". " + extTypeBlurb (juce::jmax (0, extTypeBox.getSelectedId() - 1)) + ".",
                      juce::Rectangle<int> (extX, 210, (int) extW, 54), juce::Justification::topLeft, 4);
}

void StylePanel::ExtPad::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const bool on = pressed || ctx.proc().extOn.load();
    auto r = getLocalBounds().toFloat().reduced (1.0f);
    g.setGradientFill (juce::ColourGradient ((on ? t.wine.brighter (0.5f) : t.cardHi).brighter (0.1f), r.getX(), r.getY(),
                                             (on ? t.wine : t.card).darker (0.1f), r.getX(), r.getBottom(), false));
    g.fillRoundedRectangle (r, 10.0f);
    g.setColour (on ? t.wine.brighter (1.0f) : t.panelEdge);
    g.drawRoundedRectangle (r, 10.0f, on ? 2.0f : 1.0f);
    g.setFont (uiFont (22.0f, true).withExtraKerningFactor (0.12f));
    g.setColour (t.text);
    g.drawText ("EXT", r.withTrimmedBottom (22.0f), juce::Justification::centred);
    g.setFont (uiFont (9.5f, true));
    g.setColour (t.text.withAlpha (0.75f));
    g.drawText (on ? "PLAYING" : "HOLD", r.withTrimmedTop (r.getHeight() - 34.0f), juce::Justification::centred);
}

void StylePanel::showTriggerMenu()
{
    juce::PopupMenu m;
    m.addItem (1, "Learn: press any key, pad or pedal on your controller");
    m.addItem (2, "Sustain pedal (CC64)");
    m.addItem (3, "Mod wheel (CC1, push up)");
    m.addSeparator();
    m.addItem (4, "None (on-screen EXT pad only)");
    juce::Component::SafePointer<StylePanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&triggerBtn), [safe] (int r)
    {
        if (safe == nullptr || r == 0) return;
        auto& p = safe->ctx.proc();
        if (r == 1) p.learnArmed.store (true);
        else
        {
            p.learnArmed.store (false);
            if (r == 2) { p.extTrigType.store (2); p.extTrigNum.store (64); }
            if (r == 3) { p.extTrigType.store (2); p.extTrigNum.store (1); }
            if (r == 4) { p.extTrigType.store (0); p.extTrigNum.store (-1); }
        }
        safe->repaint();
    });
}

void StylePanel::timerCallback()
{
    auto& p = ctx.proc();
    const auto lc = p.learnCount.load();
    const bool on = p.extOn.load(), armed = p.learnArmed.load();
    const int rh = ctx.lastPlayed().rhythm;
    if (lc != lastLearn || armed != lastArmed || rh != lastRhythmShown)
    {
        lastLearn = lc;
        lastArmed = armed;
        lastRhythmShown = rh;
        repaint();
    }
    if (on != lastExtOn)
    {
        lastExtOn = on;
        extPad.repaint();
    }
}
